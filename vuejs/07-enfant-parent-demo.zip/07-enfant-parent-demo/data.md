```javascript

movies: [
    {imgPath: '1.webp', title: "La guerre des roses", from: "Jay Roach"},
    {imgPath: '2.jpg', title: "Pris au piège", from: "Darren Aronofsky"},
]
```